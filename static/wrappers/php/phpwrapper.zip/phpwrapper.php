<?php
/*
  ### Important - Set your API key on line 18 ###

  PHP wrapper for the cURL functions at: https://developer.jsecoin.com/samples
  Setup an account at: https://jsecoin.com/o/?a=2895
  API Key and access levels can be found in the settings page.

  Examples at the bottom of the file
*/

if (!function_exists('curl_version')) {
  echo 'Please install cURL on your web server';
}

function curl_api_query($jse_api_url) {
  // Set your API key below
  $jse_api_key = '';
  
  $ch = curl_init();
  //curl_setopt($ch, CURLOPT_VERBOSE, true);
  //echo $jse_api_url;
  curl_setopt($ch, CURLOPT_URL,$jse_api_url);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // remove for https production env
  curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json','Authorization: '.$jse_api_key]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  $server_output = curl_exec($ch);
  curl_close($ch);
  return $server_output;
}

function jse_balance() {
  return curl_api_query('https://api.jsecoin.com/v1.7/balance/auth/0/');
}

function jse_lookup($jse_lookup) {
  return curl_api_query('https://api.jsecoin.com/v1.7/balance/auth/'.urlencode($jse_lookup).'/');
}

function jse_export($jse_value) {
  return curl_api_query('https://api.jsecoin.com/v1.7/export/auth/'.$jse_value.'/');
}

function jse_import($jse_coincode) {
  return curl_api_query('https://api.jsecoin.com/v1.7/import/auth/'.$jse_coincode.'/');
}

function jse_transfer($jse_to,$jse_value,$jse_reference) {
  return curl_api_query('https://api.jsecoin.com/v1.7/transfer/auth/'.urlencode($jse_to).'/'.$jse_value.'/'.urlencode($jse_reference).'/');
}

function jse_history() {
  return curl_api_query('https://api.jsecoin.com/v1.7/history/auth/');
}

function jse_mining() {
  return curl_api_query('https://api.jsecoin.com/v1.7/mining/auth/');
}

/*
Examples:
--------------------------------
// Simple export command
echo jse_export(0.02);
--------------------------------
// How to decode the JSON response
$result = jse_balance();
$obj = json_decode($result);
echo $obj->{'balance'};
--------------------------------
// lookup a siteID or subID balance
echo jse_lookup('example.com');
--------------------------------
//Make a transfer
echo jse_transfer('charity@jsecoin.com',1,'from php');
*/


?>